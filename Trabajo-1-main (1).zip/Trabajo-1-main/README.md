# Trabajo-1

Primero se creo un index o en este caso formulario mal escrito basico en el cula solo se podian cargar las mateira y agregarlas. con esto se creo la respectiva app y el server node. hubo un erro y lo cree sin darme cuenta en express.
despues de cambiar muchas cosas sin saber al final cual fue la corecta se borro todo express de mi codigo y se agrego unas exepciones de seguridad CORS ya que tiraba una falla que impédia visualizar los cambios en el server.
despues se agregaron los botones de borrar, borrar todo y descargar en JSON. mas adelante se prosedio a crear una base de datos online y usar workbench como visualizar para la misma. se prosede a crear las respectivas clases para 
poder utilizar ORS. se intala el squeliza para y se procede a hacer los respectivos cambios en el archivo server. todo funciona correctamente.