const { Sequelize } = require('sequelize');

// Configura la conexión a la base de datos MySQL
const sequelize = new Sequelize('bs6qgifdlmld3bv0d0ma', 'uoukgmbzmxriqcwg', 'BHWpOLYvHUHJCZDeeOea', {
    host: 'bs6qgifdlmld3bv0d0ma-mysql.services.clever-cloud.com',
    dialect: 'mysql',
    port: 3306
});

module.exports = sequelize;