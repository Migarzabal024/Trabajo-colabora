const { Model, DataTypes } = require('sequelize');
const sequelize = require('./db');

class Materia extends Model {}

Materia.init({
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    materia: {
        type: DataTypes.STRING,
        allowNull: false
    },
    alumnos: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    sequelize,
    modelName: 'Materia',
    timestamps: false // Opcional: desactiva las marcas de tiempo (createdAt, updatedAt)
});

module.exports = Materia;