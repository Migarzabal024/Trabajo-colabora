const http = require('http');
const { StringDecoder } = require('string_decoder');
const sequelize = require('./db'); // Importar configuración de base de datos
const Materia = require('./Materia'); // Importar el modelo Materia

const server = http.createServer(async (req, res) => {
    // Agregar cabeceras CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Manejar la solicitud de preflight
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        return res.end();
    }

    const method = req.method.toLowerCase();
    const path = req.url.toLowerCase();

    // Manejar la creación de una nueva materia
    if (method === 'post' && path === '/materias') {
        const decoder = new StringDecoder('utf-8');
        let buffer = '';

        req.on('data', (data) => {
            buffer += decoder.write(data);
        });

        req.on('end', async () => {
            buffer += decoder.end();
            try {
                const { materia, alumnos } = JSON.parse(buffer);
                const newMateria = await Materia.create({ materia, alumnos });
                res.writeHead(201, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ message: 'Materia agregada con éxito', materia: newMateria }));
            } catch (error) {
                res.writeHead(400);
                res.end(JSON.stringify({ message: 'Error al procesar la solicitud' }));
            }
        });
    } 
    // Manejar la obtención de todas las materias
    else if (method === 'get' && path === '/materias') {
        const materias = await Materia.findAll(); // Obtener todas las materias
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(materias));
    } 
    // Manejar la eliminación de una materia por ID
    else if (method === 'delete' && path.startsWith('/materias/')) {
        const id = parseInt(path.split('/')[2]);
        const deletedCount = await Materia.destroy({ where: { id } });
        if (deletedCount) {
            res.writeHead(204);
            res.end();
        } else {
            res.writeHead(404);
            res.end(JSON.stringify({ message: 'Materia no encontrada' }));
        }
    } 
    // Manejar la eliminación de todas las materias
    else if (method === 'delete' && path === '/materias') {
        await Materia.destroy({ where: {} }); // Eliminar todas las materias
        res.writeHead(204);
        res.end();
    } 
    // Manejar rutas no encontradas
    else {
        res.writeHead(404);
        res.end(JSON.stringify({ message: 'Ruta no encontrada' }));
    }
});

// Sincronizar la base de datos
sequelize.sync().then(() => {
    console.log('Base de datos y tablas creadas');
});

// Iniciar el servidor
const PORT = 3001;
server.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
