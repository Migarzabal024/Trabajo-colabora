const form = document.getElementById('materiaForm');
const materiasTable = document.getElementById('materiasTable');
const borrarTodoBtn = document.getElementById('borrarTodo');

// Escuchar el evento submit para agregar una nueva materia
form.addEventListener('submit', async (e) => {
    e.preventDefault(); // Prevenir el comportamiento por defecto del formulario

    const materia = document.getElementById('materia').value;
    const alumnos = document.getElementById('alumnos').value;

    const response = await fetch('http://localhost:3000/materias', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ materia, alumnos })
    });

    if (response.ok) {
        cargarMaterias();
    } else {
        console.error('Error al crear la materia');
    }

    form.reset();
});

// Función para cargar todas las materias (GET)
async function cargarMaterias() {
    const res = await fetch('http://localhost:3000/materias');
    const data = await res.json();

    materiasTable.innerHTML = '';

    data.forEach(materia => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${materia.materia}</td><td>${materia.alumnos}</td>`;
        materiasTable.appendChild(row);
    });
}

// Agregar un listener al botón para borrar todas las materias
borrarTodoBtn.addEventListener('click', async () => {
    const response = await fetch('http://localhost:3000/materias', {
        method: 'DELETE'
    });

    if (response.ok) {
        cargarMaterias();
    } else {
        console.error('Error al borrar las materias');
    }
});

// Cargar las materias al iniciar la página
cargarMaterias();
